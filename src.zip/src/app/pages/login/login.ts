// src/app/pages/login/login.ts

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { ReactiveFormsModule, FormBuilder,
         FormGroup, Validators, 
         FormsModule} from '@angular/forms';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {

  // Formulaire réactif
  loginForm: FormGroup;

  // Message d'erreur
  errorMessage: string = '';

  // Chargement
  isLoading: boolean = false;

  // Afficher/masquer mot de passe
  showPassword: boolean = false;

  constructor(
    private fb: FormBuilder,       // Pour construire le formulaire
    private authService: AuthService,
    private router: Router
  ) {
    // Créer le formulaire avec validations
    this.loginForm = this.fb.group({
      email: [
        '',
        [Validators.required, Validators.email]
      ],
      password: [
        '',
        [Validators.required, Validators.minLength(6)]
      ]
    });
  }

  // Raccourcis pour accéder aux champs
  get email()    { return this.loginForm.get('email'); }
  get password() { return this.loginForm.get('password'); }

  // Soumettre le formulaire
  onSubmit(): void {
    // Si formulaire invalide → marquer tous les champs
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const { email, password } = this.loginForm.value;

    // Simuler un délai de connexion (UX réaliste)
    setTimeout(() => {
      const success = this.authService.login(email, password);

      if (success) {
        // Connexion réussie → redirection vers accueil
        this.router.navigate(['/']);
      } else {
        // Échec → message d'erreur
        this.errorMessage = 'Email ou mot de passe incorrect.';
        this.isLoading = false;
      }
    }, 800);
  }

  // Basculer visibilité mot de passe
  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }
}