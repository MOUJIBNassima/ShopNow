// src/app/pages/checkout/checkout.ts

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { ReactiveFormsModule, FormBuilder,
         FormGroup, Validators } from '@angular/forms';
import { CartService } from '../../services/cart';
import { AuthService } from '../../services/auth';
import { CartItem } from '../../models/cart-item.model';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule],
  templateUrl: './checkout.html',
  styleUrl: './checkout.css'
})
export class Checkout implements OnInit {

  // Formulaire de commande
  checkoutForm: FormGroup;

  // Articles du panier
  cartItems: CartItem[] = [];

  // Étapes : 1 = livraison, 2 = confirmation
  currentStep: number = 1;

  // Commande passée avec succès
  orderSuccess: boolean = false;

  // Numéro de commande généré
  orderNumber: string = '';

  // Frais livraison
  shippingFee: number = 5.99;
  freeShippingThreshold: number = 50;

  constructor(
    private fb: FormBuilder,
    private cartService: CartService,
    private authService: AuthService,
    private router: Router
  ) {
    this.checkoutForm = this.fb.group({
      // Infos personnelles
      firstName: ['', [Validators.required]],
      lastName:  ['', [Validators.required]],
      email:     ['', [Validators.required, Validators.email]],
      phone:     ['', [Validators.required,
                       Validators.pattern(/^[0-9]{10}$/)]],
      // Adresse
      address:  ['', [Validators.required, Validators.minLength(5)]],
      city:     ['', [Validators.required]],
      zipCode:  ['', [Validators.required,
                      Validators.pattern(/^[0-9]{5}$/)]],
      country:  ['Maroc', [Validators.required]],
      // Paiement
      paymentMethod: ['card', [Validators.required]]
    });
  }

  ngOnInit(): void {
    // Charger les articles du panier
    this.cartItems = this.cartService.getCartItems();

    // Pré-remplir avec les infos de l'utilisateur connecté
    const user = this.authService.getCurrentUser();
    if (user) {
      this.checkoutForm.patchValue({
        firstName: user.firstName,
        lastName:  user.lastName,
        email:     user.email
      });
    }
  }

  // Raccourcis champs
  get firstName()     { return this.checkoutForm.get('firstName'); }
  get lastName()      { return this.checkoutForm.get('lastName'); }
  get email()         { return this.checkoutForm.get('email'); }
  get phone()         { return this.checkoutForm.get('phone'); }
  get address()       { return this.checkoutForm.get('address'); }
  get city()          { return this.checkoutForm.get('city'); }
  get zipCode()       { return this.checkoutForm.get('zipCode'); }
  get paymentMethod() { return this.checkoutForm.get('paymentMethod'); }

  // Totaux
  getSubtotal(): number { return this.cartService.getTotal(); }

  getShipping(): number {
    return this.getSubtotal() >= this.freeShippingThreshold
      ? 0 : this.shippingFee;
  }

  getTotal(): number {
    return this.getSubtotal() + this.getShipping();
  }

  // Soumettre la commande
  onSubmit(): void {
    if (this.checkoutForm.invalid) {
      this.checkoutForm.markAllAsTouched();
      return;
    }

    // Générer un numéro de commande aléatoire
    this.orderNumber = 'SN-' +
      Date.now().toString().slice(-6).toUpperCase();

    // Vider le panier
    this.cartService.clearCart();

    // Afficher la confirmation
    this.orderSuccess = true;
    this.currentStep = 2;
  }

  // Retour à l'accueil après commande
  goHome(): void {
    this.router.navigate(['/']);
  }
}